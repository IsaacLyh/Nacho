ReadMe:

A14331165 Derun Gu
A91018743 Yuhang Lian

Our code worked well with all given tests. 
We passed all tests we can find from nachos/test and online. 
What's more, we write some own c files to test our program. It works as expected.
 
We both contributed to the final work.
We seperated different functions at first and implemented them separately. 
We then combined our work together, read through and double checked the whole program and debugged our program together.
